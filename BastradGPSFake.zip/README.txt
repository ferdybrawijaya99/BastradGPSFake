BASTRAD GPS FAKE - Android WebView Template


Package name: com.bastrad.fakegps


Instructions:
1. Build your web app and copy the entire contents of its dist/ into app/src/main/assets/dist/
2. Open this project in Android Studio.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated APK on your device.

Note: This template includes a placeholder dist/index.html -- replace with your real build.
